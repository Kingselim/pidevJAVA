package com.esprit.controllers;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONObject;
        //String apiKey = "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";
//sk-proj-gYfMzEyq7JYt710SClv2T3BlbkFJjh1aCiOSKbpltoxHjo4c
public class ChatGPTAPIExample {



}