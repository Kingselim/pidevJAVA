package com.esprit.tests;

import com.esprit.models.Wallet;
import com.esprit.services.UserService;
import com.esprit.services.WalletService;

public class MainProg {

    public static void main(String[] args) {
        UserService us = new UserService();
        //us.ajouter(new User("Gaaloull", "Selim", "13-06-2003", "50111079", "selim03@gmail.com", "Hammamet", "slouma123", "ACTIVE", "ADMIN", "c://image.jpg", "Homme"));
        //us.modifier(new User(5,"Gaaloul", "Selim", "13-06-2003", "50111079", "selim03@gmail.com", "Hammamet", "slouma123", "ACTIVE", "ADMIN", "c://image.jpg", "Homme"));
        //us.supprimer(new User(5,"Gaaloul", "Selim", "13-06-2003", "50111079", "selim03@gmail.com", "Hammamet", "slouma123", "ACTIVE", "ADMIN", "c://image.jpg", "Homme"));
        //System.out.println(us.afficher());




        //WalletService ws = new WalletService();
        //ws.ajouter(new Wallet(2,2,5));
        //
        // ws.modifier(new Wallet(2,3,2,5));
        //ws.supprimer(new Wallet(2,3,2,5));
        //System.out.println(ws.afficher());

//        ps.ajouter(new Personne("Ahmed", "Med"));
//        System.out.println(ps.afficher());
        //PersonneService2 ps2 = new PersonneService2();

    }
}
